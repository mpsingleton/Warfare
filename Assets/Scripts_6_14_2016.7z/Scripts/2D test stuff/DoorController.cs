﻿using UnityEngine;
using System.Collections;

public class DoorController: MonoBehaviour {

    public Collider doorVolume;
    public GameObject exit;





	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
