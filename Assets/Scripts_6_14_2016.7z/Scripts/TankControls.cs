﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public class AxleInfo {
	public WheelCollider leftWheel;
	public WheelCollider rightWheel;
	public bool motor; //is this wheel attached to motor?
	public bool steering; //does this wheel apply steering angle?
}

public class TankControls : MonoBehaviour {

	GameObject hull;
	Rigidbody hullRigidBody;
	public Transform turnCenter;

	static int turretCount = 1;
	public TurretControlsTank[] turretControlsTank = new TurretControlsTank[turretCount];
	public List<AxleInfo> axleInfos;
	public GameObject shell;

	enum FireMode {FullSalvo, TurretSalvo, SingleFire};
	FireMode fireMode = FireMode.SingleFire;

	public int throttle = 0;//this goes from -2 to 2. full reverse to full ahead.

	public float torque = 2;

	/*
	public float accelMax = .1f; //caps accelCurrent
	public float accelCurrent = 0f; //current cumulative acceleration added per physics step.
	public float speedAccel = .01f; //increment added to the cumulative per physics step.
	public float speedMax = 20f;//maximum speed allowed, enforced by idealDrag
	public float idealDrag; //adjusted drag value to enforce top speed.
	public float speedDecay = .8f; //how fast speed decays after thrust is cut.
	public float lateralSpeed;
	
	public bool rotationAxisActive = false;
	public float turnMax = 1f; //caps turnCurrent
	public float turnCurrent = 0f; //current cumulative turning added per physics step.
	public float turnAccel = .2f; //increment added to the cumulative per physics step.
	public float turnSpeedMax = 10f; //maximum turn speed allowed, enforced by idealDrag;
	public float turnDecay = .8f;
	*/

	int count = 0;

	// Use this for initialization
	void Start () {
		hull = this.gameObject;
		hullRigidBody = hull.GetComponent<Rigidbody>();
		ComponentAssignment ();
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		Throttle();
		Engine();
		Turn();

		if(Input.GetButtonDown("Fire1")){
			Debug.Log(turretControlsTank[0].gunsReady);  //checks to make sure the linkage to turret control is working properly
			if(fireMode == FireMode.FullSalvo){
				FullSalvo ();
			}
			else if(fireMode == FireMode.TurretSalvo){
				TurretSalvo();
			}
			else if(fireMode == FireMode.SingleFire){
				SingleFire();
			}

		}
	}


	void ComponentAssignment(){
		count = 0;
		Transform[] allChildren = GetComponentsInChildren<Transform>();
		foreach(Transform child in allChildren){
			if(child.gameObject.name == "Turret_Main"){
				child.gameObject.name = "Turret_Main_0" + (count + 1);
				turretControlsTank[count] = child.GetComponent<TurretControlsTank>();
				count++;
			}
		}
	}


	void Throttle(){
		if(Input.GetAxisRaw("Vertical") > 0){

			throttle = 2;

		}
		else if(Input.GetAxisRaw("Vertical") < 0){

			throttle = -2;
	
		}
		else if(Input.GetAxisRaw("Vertical") == 0){	//add actual throttle decay later

			throttle = 0;

		}
	}

	void Engine() {
		foreach (AxleInfo axleInfo in axleInfos){
			if (axleInfo.motor){
				axleInfo.leftWheel.motorTorque = torque * throttle;
				axleInfo.rightWheel.motorTorque = torque * throttle;
			}
		}
	}


	void Turn(){
		if(Input.GetAxisRaw("Horizontal") < 0){
			throttle = 2;
			foreach (AxleInfo axleInfo in axleInfos){
				if (axleInfo.motor){
					axleInfo.leftWheel.motorTorque = -1 * (torque * throttle);
					axleInfo.rightWheel.motorTorque = torque * throttle;
				}
			}
		}
		if(Input.GetAxisRaw("Horizontal") > 0){
			throttle = 2;
			foreach (AxleInfo axleInfo in axleInfos){
				if (axleInfo.motor){
					axleInfo.leftWheel.motorTorque = torque * throttle;
					axleInfo.rightWheel.motorTorque = -1 * (torque * throttle);
					Debug.Log(throttle * torque);
				}
			}
		}
		if(Input.GetAxis("Horizontal") == 0){
			throttle = 0;
		}
	}


	void FullSalvo(){
		count = 0;
		while (count < turretCount){
			if(turretControlsTank[count].gunsReady == turretControlsTank[count].gunsTotal 
			   && turretControlsTank[count].elevReady && turretControlsTank[count].rotReady){
				turretControlsTank[count].fireSalvo = true;
			}
			else{
				//Turret not ready!
			}
			count++;
		}		
	}

	
	void TurretSalvo(){
		count = 0;
		while(count < turretCount){
			if(turretControlsTank[count].gunsReady == turretControlsTank[count].gunsTotal 
			   && turretControlsTank[count].rotReady && turretControlsTank[count].elevReady){
				turretControlsTank[count].fireSalvo = true;
				break;
			}
			else{
				count++;
			}
		}
	}

	//this is the current holdup. this code isn't linking up properly with the TurretControlsTank script, so the gun won't fire.
	//apparently the assignment section is broken, because accessing the turretControlsTank script is NullRefing
	void SingleFire(){
		count = 0;
		while(count < turretCount){

			if(turretControlsTank[count].gunsReady > 0 && turretControlsTank[count].elevReady 
			   && turretControlsTank[count].rotReady){
				turretControlsTank[count].fireSingle = true;
				break;
			}
			else{
				count++;
			}
		}
	}





	/*
	void Turn(){
		if(Input.GetAxisRaw("Horizontal") != 0){
			if(rotationAxisActive == false){
				rotationAxisActive = true;
			}
		}
		if(Input.GetAxisRaw("Horizontal") == 0 && rotationAxisActive == true){
			//TurnCurrentDecay();
			rotationAxisActive = false;
		}
		
		if(rotationAxisActive == true){
			TurnCurrentIncrease();
		}
	}
	*/


	/*
	void TurnCurrentIncrease(){
		if(Input.GetAxis("Horizontal") > 0){
			if(turnCurrent < turnSpeedMax){
				turnCurrent += turnAccel;
			}
			else if(turnCurrent > turnSpeedMax){
				turnCurrent = turnSpeedMax;
			}
		}
		else if(Input.GetAxis("Horizontal") < 0) {
			if(Mathf.Abs(turnCurrent) < turnSpeedMax){
				turnCurrent -= turnAccel;
			}
			else if(Mathf.Abs(turnCurrent) > turnSpeedMax){
				turnCurrent = turnMax * -1;
			}
			
		}

		hullRigidBody.AddTorque (transform.up * turnCurrent);

		if(accelCurrent == 0){
			hullRigidBody.AddTorque (transform.up * turnCurrent);
			hullRigidBody.AddRelativeForce(speedAccel, 0, 0);
		}
		else{
			hullRigidBody.AddTorque (transform.up * (turnCurrent / accelCurrent));
		}

		
	}
	*/

	/*
	void TurnCurrentDecay(){
		if(turnCurrent > 0 && turnCurrent > .001){
			turnCurrent = turnCurrent * turnDecay;
		}
		else if(turnCurrent < 0 && turnCurrent < -.001){
			turnCurrent = (Mathf.Abs(turnCurrent) * turnDecay) * -1;
		}
		else{
			turnCurrent = 0;
			rotationAxisActive = false;
		}
	}
	*/



	





	/*

	*/


}





