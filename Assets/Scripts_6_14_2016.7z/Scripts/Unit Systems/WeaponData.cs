﻿using UnityEngine;
using System.Collections;

//WeaponData stores reference data for different weapon types. 





public class WeaponData : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
