﻿using UnityEngine;
using System.Collections;

public class Ammo_AP : MonoBehaviour {

    public string ammoType = "Mk1 Armor Piercing";
    public GameObject icon;
    float velMod = 1;
    float penMod = 1;
    float normalization = 1;
    float Damage = 300;
    float splashRadius = 5;
    float splashDamage = 10;
}
