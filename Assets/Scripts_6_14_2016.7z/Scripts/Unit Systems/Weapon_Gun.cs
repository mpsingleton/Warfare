﻿using UnityEngine;
using System.Collections;

public class Weapon_Gun : MonoBehaviour {

    //weapon
    public string weaponType = "152mm D11 K Howitzer";
    public Transform muzzle;

    public GameObject shell;
    GameObject[] shellPool = new GameObject[6];
    int shellCount = 0;

    //Ammo variables
    public GameObject[] ammoTypes = new GameObject[1]; //Store types of shells here.
    float caliber = 152f; //caliber in mm. use this for overmatch, damage multipliers, spalling.
    float shellSize = 10.5f; //use this one to calculate how many rounds can be held in a magazine.
    public float shellForce = 2000f; //modified by shell type.
    float dispersion = 0.0f;

    //Firing Mode Variables
    bool singleFire = true;
    float breechLoadTime = 5.5f; //base load time, modified by turret;

    bool rippleFire = false; //move these to a mount script?
    bool salvoFire = false;

    bool burstFire = false;
    bool autoFire = false;
    int magCapacity = 1; //if this isn't greater than 1, set burstFire and autoFire to false;
    float magLoadTime = 0.0f;

    public bool loaded = false;
    public bool fire = false;

    int count = 0;


    // Use this for initialization
    void Start () {
        if(burstFire || autoFire && magCapacity < 2) {
            burstFire = false;
            autoFire = false;
            Debug.Log("burst/auto fire require a magazine");
        }
        ShellPool();
        StartCoroutine(Reload());
    }
	
	// Update is called once per frame
	void Update () {

        if (fire) {
            fire = false;
            if (loaded)
            {
                Fire();
            }
            else {
                Debug.Log("GUN NOT LOADED!");
            }
        }
	}



    void Fire() {

        if (shellCount >= shellPool.Length)
        {
            shellCount = 0;
        }

        Rigidbody rb = shellPool[shellCount].GetComponent<Rigidbody>();
        rb.velocity = new Vector3(0, 0, 0);
        shellPool[shellCount].transform.position = muzzle.position;
        shellPool[shellCount].transform.rotation = muzzle.rotation;
        shellPool[shellCount].SetActive(true);
        rb.AddRelativeForce(Vector3.forward * shellForce);
        shellCount++;

        loaded = false;
        StartCoroutine(Reload());
    }

    IEnumerator Reload() {
        yield return new WaitForSeconds(breechLoadTime);
        loaded = true;
    }

    void ShellPool() {
        count = 0;
        while (count < shellPool.Length)
        {
            float varX = this.transform.position.x;
            float varY = this.transform.position.y;
            float varZ = this.transform.position.z;
            shellPool[count] = Instantiate(shell, new Vector3(varX, varY, varZ), Quaternion.identity) as GameObject;
            shellPool[count].transform.parent = this.transform;
            count++;
        }
    }




}
