﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TurretControls : MonoBehaviour {
	
	public Transform turret;
	public Transform rotKey;
	public Transform rotTarget;
	public Transform elevTarget;
	public Transform gun;
	public Transform muzzle;

	public Transform aimPoint;

	float turnSpeed = .2f;
	float leftLimit = 30f;
	float rightLimit = 330f;

	float elevSpeed = .1f;
	float elevLimit = 45f;
	float depressLimit = -5f;
	float elevCheck = 0f;
	float elevCurrent = 0f;

	List<GunIndex> gunIndex = new List<GunIndex>();

	public GameObject shell; //do it manually now, fix it later.
	GameObject[] shellPool = new GameObject[6];
	ShellType selectedShell = ShellType.ArmorPiercing;
	float shellForce = 2000;
	float shellVelocity;
	int shellCount = 0;
	
	public bool elevReady = false;
	public bool rotReady = false;
	public int gunsReady = 0; //ripple fire is go if this doesn't equal 0, salvo fire if it equals gunsTotal
	public int gunsTotal; //equals gunIndex.Count
	int gunCount = 0;//used for stepping through all barrels.
	float loadTime = 5.5f;

	public bool fireSalvo = false;
	public bool fireSingle = false;

	int count = 0;

	//the following variables are for the trajectory calculations I found.
	bool haveFiringSolution = false;
	bool directFire = true; //ah, we use flight time to decide whether to set it high or low. nice!
	public float maxRange;
	float firingSolution;	



	// Use this for initialization
	void Start () {
		ComponentAssignment();
		maxRange = CalculateMaximumRange();
		shellVelocity = shellForce * Time.fixedDeltaTime;
	}

	
	// Update is called once per frame
	void LateUpdate () {
		TurretRotation();
		count = 0;
		while(count < gunsTotal){
			GunElevation(gunIndex[count].gun);
			count++;
		}

		if(fireSalvo == true){
			fireSalvo = false;
			FireSalvo();
		}
		else if(fireSingle == true){
			fireSingle = false;
			FireSingle();
		}


	}

	void TurretRotation(){
		rotKey.position = aimPoint.position;
		rotKey.position = new Vector3(aimPoint.position.x, turret.transform.position.y, aimPoint.position.z);
		rotTarget.LookAt(rotKey);

		if(rotTarget.localEulerAngles.y > rightLimit || rotTarget.localEulerAngles.y < leftLimit){
			rotReady = false;
		}

		if(turret.localEulerAngles.y > rotTarget.localEulerAngles.y){
			if(turret.localEulerAngles.y > leftLimit){
				turret.Rotate (Vector3.up * (turnSpeed * -1));
			}
		}
		else if(turret.localEulerAngles.y < rotTarget.localEulerAngles.y){
			if(turret.localEulerAngles.y < rightLimit){
				turret.Rotate (Vector3.up * turnSpeed);
			}
		}

		//check if we're on or off target.
		if(Mathf.Abs (turret.localEulerAngles.y - rotTarget.localEulerAngles.y) < 3){
			if(Mathf.Abs (turret.localEulerAngles.y - rotTarget.localEulerAngles.y) < turnSpeed){
				turret.localEulerAngles = new Vector3 (0, rotTarget.localEulerAngles.y, 0);
				rotReady = true;
			}
		}
		else{
			rotReady = false;
		}

		//true up rotation to limits.
		if(turret.localEulerAngles.y < leftLimit){
			turret.localEulerAngles = new Vector3 (0, leftLimit, 0);
		}
		if(turret.localEulerAngles.y > rightLimit){
			turret.localEulerAngles = new Vector3 (0, rightLimit, 0);
		}
	}
	
	void GunElevation(Transform gun){
		firingSolution = CalculateProjectileFiringSolution() * Mathf.Rad2Deg;

		if(firingSolution == 0){
			firingSolution = elevLimit * -1;
			elevReady = false;
		}
		else if(firingSolution > 5){
			firingSolution = depressLimit * -1;
			elevReady = false;
		}

		elevTarget.eulerAngles = new Vector3(firingSolution, turret.eulerAngles.y, 0);

		elevCheck = FixEulerAngles(elevTarget.localEulerAngles.x);
		elevCurrent = FixEulerAngles(gun.localEulerAngles.x);

		if(elevCurrent < elevCheck){
			gun.Rotate (Vector3.right * (elevSpeed * -1));//elevate
		}
		else{
			gun.Rotate (Vector3.right * elevSpeed);//depress
		}
		if(Mathf.Abs (elevCheck - elevCurrent) < 3){
			if(Mathf.Abs(elevCheck - elevCurrent) < elevSpeed){
				gun.localEulerAngles = new Vector3(elevTarget.localEulerAngles.x, 0, 0);
				elevReady = true;
			}		
		}
		else{
			elevReady = false;
		}
	}

	float FixEulerAngles(float rotSource){
		if(rotSource > 180){
			return (rotSource - 360) * -1;
		}
		else{
			return rotSource * -1;
		}
	}




	void FireSalvo(){
		gunCount = 0;
		while(gunCount < gunsTotal){
			FireShell(gunIndex[gunCount].muzzle);
			gunIndex[gunCount].State = GunState.Loading;
			StartCoroutine(ReloadTimer(gunCount));
			gunCount++;
		}
	}

	void FireSingle(){
		gunCount = 0;
		while(gunCount < gunsTotal){
			if(gunIndex[gunCount].State == GunState.Ready){
				FireShell (gunIndex[gunCount].muzzle);
				StartCoroutine(ReloadTimer(gunCount));
				break;
			}
			else{
				gunCount++;
			}
		}


	}

	void FireShell(Transform gunMuzzle){
		if(shellCount >= shellPool.Length){
			shellCount = 0;
		}
		Rigidbody rb = shellPool[shellCount].GetComponent<Rigidbody>();
		rb.velocity = new Vector3(0,0,0);
		shellPool[shellCount].transform.position = gunMuzzle.position;
		shellPool[shellCount].transform.rotation = gunMuzzle.rotation;
		shellPool[shellCount].SetActive(true);
		rb.AddRelativeForce(Vector3.forward * shellForce); //transform gave wonky results, Vector3 worked.
		shellCount++;
		gunsReady--;
	}

	IEnumerator ReloadTimer(int gunToLoad){
		yield return new WaitForSeconds(loadTime);
		gunIndex[gunToLoad].State = GunState.Ready;
		gunsReady++;
	}

	void ComponentAssignment(){
		Transform[] allChildren = GetComponentsInChildren<Transform>();
		foreach(Transform child in allChildren){
			if(child.gameObject.name == "Turret"){
				turret = child;
			}
			if(child.gameObject.name == "RotationKey"){
				rotKey = child;
			}
			if(child.gameObject.name == "RotationTarget"){
				rotTarget = child;
			}
			if(child.gameObject.name == "ElevationTarget"){
				elevTarget = child;
			}
			
			if(child.gameObject.name == "Gun"){
				gun = child;
				foreach (Transform childTransform in gun)
				{
					if(childTransform.gameObject.name == "Muzzle"){
						muzzle = childTransform;
					}
				}
				if(gun != null && muzzle != null){//this is broken atm.
					//gunIndex.Add(new GunIndex(gun, muzzle, GunState.Loading, selectedShell));
				}
				else{
					Debug.Log ("INDEXING ERROR! GUN OR MUZZLE INDEXING FAILED!");
				}
			}
		}
		gunsTotal = gunIndex.Count;
		count = 0;
		while(count < shellPool.Length){
			float varX = turret.position.x;
			float varY = turret.position.y;
			float varZ = turret.position.z;
			shellPool[count] = Instantiate(shell, new Vector3(varX, varY, varZ), Quaternion.identity) as GameObject;
			shellPool[count].transform.parent = this.transform;
			count++;
		}
		count = 0;
		while(count < gunsTotal){
			StartCoroutine(ReloadTimer (count));
			count++;
		}
	}
	
	//borrowed the following from a Unity forums answer.
	float CalculateMaximumRange() {

		float g = Physics.gravity.y; 
		float y = gunIndex[0].gun.position.y; //origin //centerpoint of the gun's transform?
		float v = shellVelocity; //projectileSpeed //possibly the value we multiply addforce with?
		float a = 45 * Mathf.Deg2Rad;
		
		float vSin = v * Mathf.Cos(a);
		float vCos = v * Mathf.Sin(a);
		
		float sqrt = Mathf.Sqrt(vSin * vSin + 2 * g * y);
		
		return Mathf.Abs((vSin / g) * (vCos + sqrt));
	}

	//borrowed the following from a Unity forums answer. http://answers.unity3d.com/questions/49195/trajectory-of-a-projectile-formula-does-anyone-kno.html
	float CalculateProjectileFiringSolution() {
		Vector3 targetTransform = aimPoint.position; //target is of course the aimPoint
		Vector3 barrelTransform = gunIndex[0].gun.position;
		
		float y = (barrelTransform.y - targetTransform.y);
		float xx = targetTransform.x - barrelTransform.x;
		float xz = targetTransform.z - barrelTransform.z;
		float x = Mathf.Sqrt(xx * xx + xz * xz);
		float v = shellVelocity;
		float g = Physics.gravity.y;
		
		float sqrt = (v*v*v*v) - (g * (g * (x*x) + 2 * y * (v*v)));
		
		// Not enough range
		
		if (sqrt < 0) {
			haveFiringSolution = false;
			return 0.0f;
		}
		
		haveFiringSolution = true;
		
		sqrt = Mathf.Sqrt(sqrt);
		
		// DirectFire chooses the low trajectory, otherwise high trajectory.
		
		if (directFire) {   
			return Mathf.Atan(((v*v) - sqrt) / (g*x));
			
		} else {
			return Mathf.Atan(((v*v) + sqrt) / (g*x));
			
		}
	}

	float CalculateFlightTime(float angle) { 
		Vector3 targetTransform = aimPoint.position;
		Vector3 barrelTransform = gunIndex[0].gun.position;
		
		float x = (targetTransform - barrelTransform).magnitude;
		float v = shellVelocity;
		
		angle = angle == 0 ? 45 : angle;
		
		float time = x / (v * Mathf.Cos(angle * Mathf.Deg2Rad));
		
		return time * .7f;

	}







	
}
