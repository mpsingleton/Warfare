﻿using UnityEngine;
using System.Collections;

/*
Rather than building this functionality into ShipControls, I thought it might 
be better to start building the basics of the ship customization code, and
keeping it seperate from the actual steering and shooting stuff. We might be 
drifting a bit from the established code goals, though...

*/


public class ShipBuilder : MonoBehaviour {




	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
