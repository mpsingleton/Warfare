﻿using UnityEngine;
using System.Collections;

public class LevelLoader : MonoBehaviour {

    public GameObject player;


    public GameObject[] areaIndex = new GameObject[2];



    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
