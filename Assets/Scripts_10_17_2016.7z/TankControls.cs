﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
/*
this script won't process a fire command unless turretcontrols' elevReady, travReady, and gunReady variables are all true.

we don't actually want turretControls handling that stuff. In fact, elevReady and gunReady should probably be on the weapon in question. TurretControls should handle rotation only.

this script should handle all direct player input. 
it should have a gunIndex built up of all the weapons in the various turrets.
it should be able to select between different guns, but all guns should be tracking the cursor at all times.
it should be passing and receiving data both from the various guns and also from the various turrets.

none of this means anything without the UI to control it, so let's start with that.
a simple readout that displays the currently selected weapon, and some buttons to change which weapon is selected.

The axles and general driving controls need to be split into a seperate script as well.


*/



[System.Serializable]
public class AxleInfo {
	public WheelCollider leftWheel;
	public WheelCollider rightWheel;
	public bool motor; //is this wheel attached to motor?
	public bool steering; //does this wheel apply steering angle?
}

public class TankControls : MonoBehaviour {

	GameObject hull;
	Rigidbody hullRigidBody;
	public Transform turnCenter;

	static int turretCount = 1;
	public TurretControlsTank[] turretControlsTank = new TurretControlsTank[turretCount];
	public List<AxleInfo> axleInfos;
	public GameObject shell;

	enum FireMode {FullSalvo, TurretSalvo, SingleFire};
	FireMode fireMode = FireMode.SingleFire;

	public int throttle = 0;//this goes from -2 to 2. full reverse to full ahead.

	public float torque = 2;

	int count = 0;

	// Use this for initialization
	void Start () {
		hull = this.gameObject;
		hullRigidBody = hull.GetComponent<Rigidbody>();
		ComponentAssignment ();
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		Throttle();
		Engine();
		Turn();

		if(Input.GetButtonDown("Fire1")){
			Debug.Log(turretControlsTank[0].gunsReady);  //checks to make sure the linkage to turret control is working properly
			if(fireMode == FireMode.FullSalvo){
				FullSalvo ();
			}
			else if(fireMode == FireMode.TurretSalvo){
				TurretSalvo();
			}
			else if(fireMode == FireMode.SingleFire){
				SingleFire();
			}

		}
	}


	void ComponentAssignment()
    {
		count = 0;
		Transform[] allChildren = GetComponentsInChildren<Transform>();
		foreach(Transform child in allChildren){
			if(child.gameObject.name == "Turret_Main"){
				child.gameObject.name = "Turret_Main_0" + (count + 1);
				turretControlsTank[count] = child.GetComponent<TurretControlsTank>();
				count++;
			}
		}
	}


	void Throttle(){
		if(Input.GetAxisRaw("Vertical") > 0){

			throttle = 2;

		}
		else if(Input.GetAxisRaw("Vertical") < 0){

			throttle = -2;
	
		}
		else if(Input.GetAxisRaw("Vertical") == 0){	//add actual throttle decay later

			throttle = 0;

		}
	}

	void Engine() {
		foreach (AxleInfo axleInfo in axleInfos){
			if (axleInfo.motor){
				axleInfo.leftWheel.motorTorque = torque * throttle;
				axleInfo.rightWheel.motorTorque = torque * throttle;
			}
		}
	}


	void Turn(){
		if(Input.GetAxisRaw("Horizontal") < 0){
			throttle = 2;
			foreach (AxleInfo axleInfo in axleInfos){
				if (axleInfo.motor){
					axleInfo.leftWheel.motorTorque = -1 * (torque * throttle);
					axleInfo.rightWheel.motorTorque = torque * throttle;
				}
			}
		}
		if(Input.GetAxisRaw("Horizontal") > 0){
			throttle = 2;
			foreach (AxleInfo axleInfo in axleInfos){
				if (axleInfo.motor){
					axleInfo.leftWheel.motorTorque = torque * throttle;
					axleInfo.rightWheel.motorTorque = -1 * (torque * throttle);
					Debug.Log(throttle * torque);
				}
			}
		}
		if(Input.GetAxis("Horizontal") == 0){
			throttle = 0;
		}
	}


	void FullSalvo(){
		count = 0;
		while (count < turretCount){
			if(turretControlsTank[count].gunsReady == turretControlsTank[count].gunsTotal 
			   && turretControlsTank[count].elevReady && turretControlsTank[count].rotReady){
				turretControlsTank[count].fireSalvo = true;
			}
			else{
				//Turret not ready!
			}
			count++;
		}		
	}

	
	void TurretSalvo(){
		count = 0;
		while(count < turretCount){
			if(turretControlsTank[count].gunsReady == turretControlsTank[count].gunsTotal 
			   && turretControlsTank[count].rotReady && turretControlsTank[count].elevReady){
				turretControlsTank[count].fireSalvo = true;
				break;
			}
			else{
				count++;
			}
		}
	}

	//shooting is broken here until we seperate the code out better.
	void SingleFire(){
        Debug.Log("SingleFire fire activated");
		count = 0;
		while(count < turretCount){

			if(turretControlsTank[count].gunsReady > 0 && turretControlsTank[count].elevReady 
			   && turretControlsTank[count].rotReady){
				turretControlsTank[count].fireSingle = true;
                Debug.Log("sending fire order to turretControlsTank script");
				break;
			}
			else{
				count++;
			}
		}
	}



}





