﻿using UnityEngine;
using System.Collections;

//GunIndex maintains a simple and efficient index of all guns in a turret.
//Each turret gets a copy.


public enum GunState {Ready, Loading, Locked};
public enum ShellType {HighExplosive, ArmorPiercing};

public class GunIndex
{
	public Transform gun;
	public Transform muzzle;
	public Transform elevationTarget;

	public GunState State;
	//public ShellType Type; //We probably need a seperate magazine component and script to provide this.
    public Weapon_Gun weapon_Gun;
    


	public GunIndex(Transform gunBarrel, Transform gunMuzzle, GunState currentState, /*ShellType currentType,*/ Weapon_Gun gunScript)
	{
		gun = gunBarrel;
		muzzle = gunMuzzle;
		State = currentState;
		//Type = currentType;
        weapon_Gun = gunScript;
	}

}